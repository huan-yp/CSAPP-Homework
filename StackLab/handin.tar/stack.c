/* 
 * Code for basic C skills diagnostic.
 */

/*
 * This program implements a stack supporting both FILO operations.
 *
 * It uses a singly-linked list to represent the set of stack elements
 */

#include <stdlib.h>
#include <stdio.h>

#include "harness.h"
#include "stack.h"


/*
  Create empty stack.
  Return NULL if could not allocate space. Use malloc 
*/
stack *s_new()
{
  stack *newstack=(stack *)malloc(sizeof(stack));
  if(newstack==NULL)
  {
    return NULL;
  }
  newstack->top=NULL;
  newstack->bottom=NULL;
  newstack->cnt=0;
  return newstack;
}

/* Free all storage used by stack */
void s_free(stack *s)
{
  while(s->top!=s->bottom)
  {
    s_node* tmp;
    tmp=s->top;
    s->top=s->top->next;
    free(tmp);
  }
  free(s->top);
  free(s);
  return;
}

/*
  Attempt to insert element at top of stack.
  Return true if successful.
  Return false if s is NULL or could not allocate space.
 */
bool s_push(stack *s, int v)
{
  s_node* tmp;
  tmp=(s_node *)malloc(sizeof(s_node));
  if(tmp==NULL||s==NULL)
  return false;
  else
  {
    tmp->value=v;
    tmp->next=s->top;
    s->top=tmp;
    s->cnt++;
    if(s->cnt==1)
    s->bottom=tmp;
    return true;
  }
}


/*
  Attempt to pop an element from the top of stack.
  Return true if successful.
  Return false if s is NULL or empty.
  If vp non-NULL and element removed, store removed value at *vp.
  Any unused storage should be freed.
 */
bool s_pop(stack *s, int *vp)
{
  if(s==NULL||s->cnt==0)
  return false;
  else
  {
    s_node* tmp;
    tmp=s->top;
    s->top=s->top->next;
    vp=&tmp->value;
    free(tmp);
    s->cnt--;
    return true;
  }
}

/*
  Return number of elements in stack.
  Return 0 if s is NULL or empty
 */
int s_size(stack *s)
{
  /* Remember: It should operate in O(1) time */
  if(s==NULL)
  return 0;
  else 
  return s->cnt;
}

/*
  Discriminate whether the stack is empty.
  Return true if s is empty or NULL, otherwise return false.
 */
bool s_empty(stack *s)
{
  if(s->cnt==0||s==NULL)
  return true;
  else
  return false;
}

/*
  Reverse elements in stack.

  Your implementation must not allocate or free any elements (e.g., by
  calling push or pop).  Instead, it should modify
  the pointers in the existing data structure.
 */
void s_reverse(stack *s)
{
  int n;
  n=0;
  s_node *pointer[s->cnt];
  pointer[0]=s->top;
  s_node *tmp;
  tmp=s->top;
  while(tmp!=s->bottom)
  {
    tmp=tmp->next;
    pointer[++n]=tmp;
  }
  for(int i=s->cnt-1;i>0;i++)
  {
    pointer[i]->next=pointer[i-1];
  }
  pointer[0]->next=NULL;
  s->top=pointer[s->cnt-1];
  s->bottom=pointer[0];
  return ;
}